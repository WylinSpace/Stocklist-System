Stocklist Tracking System

1. Compile the main.cpp in /SourceCode file.
2. If the setting.json is not configured, copy the snippets-A below
3. Please Open The Console Window to Windowed-Full-Screen for the best visual experience.
4. Enjoy.


Snippets-A :
"args": [
                "-fdiagnostics-color=always",
                "-g",
                "main.cpp",
                "cppFiles/admin.cpp",
                "cppFiles/borrow.cpp",
                "cppFiles/textstyle.cpp",
                "cppFiles/item.cpp",
                "cppFiles/user.cpp",
                "cppFiles/return.cpp",
                "-o",
                "${fileDirname}\\Stocklist_Tracker.exe"
            ],