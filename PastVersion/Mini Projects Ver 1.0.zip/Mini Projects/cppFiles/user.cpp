#ifndef USER_CPP
#define USER_CPP

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <ctime>
#include <string>
using namespace std;

class userData
{
    private:
    string userID = "None";
    string userEmail = "None";
    string userPassword = "None";
    string userName = "None";
    string filename = "Data/userID/user.csv";
    string filenameAdmin = "Data/userID/admin.csv";

    public:
    void statusCheck(){
        cout<<endl;
        cout<<"The current user registered is: "<<userEmail<<endl;
        cout<<"The current user password is: "<<userPassword<<endl;
        cout<<"The current user Name is: "<<userName<<endl;
        cout<<endl;
    }

    bool find_userEmail(string test_userEmail,string test_userPassword){
        ifstream infile(filename);
        if(infile.is_open()){
            string line;
            while(getline(infile,line)){
                stringstream ss(line);
                string cell;
                int column = 0;
                while(getline(ss,cell,',')){
                    if(column==0){
                        userEmail = cell;
                    }
                    if(column==1){
                        userPassword = cell;
                    }
                    if(column==2){
                        userID = cell;
                    }
                    if(column==3){
                        userName = cell;
                    }
                    column++;
                }
                if(test_userEmail==userEmail&&test_userPassword==userPassword){
                    infile.close();
                    return true;
                }
            }
            infile.close();
            return false;
        } else {
            cerr << "Error: Imable to open file!"<<endl;
            return false;
        }
    }

    bool find_adminEmail(string test_userEmail,string test_userPassword){
        ifstream infile(filenameAdmin);
        if(infile.is_open()){
            string line;
            while(getline(infile,line)){
                stringstream ss(line);
                string cell;
                int column = 0;
                while(getline(ss,cell,',')){
                    if(column==0){
                        userEmail = cell;
                    }
                    if(column==1){
                        userPassword = cell;
                    }
                    if(column==2){
                        userID = cell;
                    }
                    if(column==3){
                        userName = cell;
                    }
                    column++;
                }
                if(test_userEmail==userEmail&&test_userPassword==userPassword){
                    infile.close();
                    return true;
                }
            }
            infile.close();
            return false;
        } else {
            cerr << "Error: Imable to open file!"<<endl;
            return false;
        }
    }
    
    string giveUserID(){
        return userID;
    }

    string giveUserName(){
        return userName;
    }
};

#endif