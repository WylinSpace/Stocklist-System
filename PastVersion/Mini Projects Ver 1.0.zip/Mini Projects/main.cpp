#include "main.hpp"

int main(){
//Declaration Of Class
    userData Data;
    userOperationBORROW Borrow;
    userOperationRETURN Return;
    itemData item;
    
//Login Page (uses userData class)
    Data.statusCheck();
    string Email,password;
    bool check = false;
    bool checkIfAdmin = false;
    while(!check){
        cout<<"Enter Your Email > ";
        getline(cin,Email);
        cout<<"Enter Your Password > ";
        getline(cin,password);
        if(Data.find_userEmail(Email,password)){
            check = Data.find_userEmail(Email,password);
        } else {
            checkIfAdmin = true;
            check = Data.find_adminEmail(Email,password);
        }
    }

//Admin Special
    if(checkIfAdmin){
        Data.statusCheck();
        cout<<"Please choose the operation:"<<endl;
        cout<<"1 - Borrow Item"<<endl;
        cout<<"2 - Return Item"<<endl;
        cout<< RED <<"3 - Admin Page" << RESET <<endl;
        cout<<"Press other buttons to Exit."<<endl; 
    } 

//Transit To Borrow Or Return
    else {
        Data.statusCheck();
        cout<<"Please choose the operation:"<<endl;
        cout<<"1 - Borrow Item"<<endl;
        cout<<"2 - Return Item"<<endl;
        cout<<"Press other buttons to Exit."<<endl;
    }
    int BorrowOrReturn;
    cin>>BorrowOrReturn;

//Borrow (Uses userData class & item Class)    
    if(BorrowOrReturn==1){ 
        bool borrowLoop = false;
        int itemChoosenInt;
        string itemChoosen;
        bool failedborrowLoop = false;
        do{
            do{    
                item.itemList();
                cout<<"(Enter 0 to Exit the Page)"<<endl;
                cout<<"Enter The Item You wish to borrow: ";
                cin>>itemChoosenInt;
                itemChoosen = to_string(itemChoosenInt);
                if(itemChoosen=="0") {
                    borrowLoop = true;
                    break;
                }
                failedborrowLoop = item.itemFind(itemChoosen);
            } while (!failedborrowLoop);
            if(itemChoosen!="0") Borrow.userDataWRITE(Data.giveUserID(),itemChoosen);
        } while (!borrowLoop);
    } 
    
//Return (Uses userData Class & itemClass)
    else if(BorrowOrReturn==2){
        bool returnLoop = false;
        do{
            Return.displayItemBorrowed(Data.giveUserID(),Data.giveUserName());
            cout<<"(Enter 0 to Exit the Page)"<<endl;
            cout<<"Enter the item you wish to return according to the item number displayed at left > ";
            int returnedItem;
            cin>>returnedItem;
            if(returnedItem==0) {
                    returnLoop = true;
                    break;
                }
            Return.deleteReturnItem(returnedItem);
        }while (!returnLoop);
    }

//Admin Page
    else if(BorrowOrReturn==3 && checkIfAdmin){
        admin admin;
        cout<<"Please choose the operation:"<<endl;
        cout<<"1 - View Penalty List"<<endl;
        cout<<"2 - View Stock List"<<endl;
        cout<<"3 - Make Purchase Request"<<endl;
        cout<<"Press other buttons to Exit."<<endl; 
        int adminPageOperation;
        cin>>adminPageOperation;
        if(adminPageOperation==1){
            admin.displayPenaltyList();
        } else if(adminPageOperation==2){
            item.itemList();
        } else if(adminPageOperation==3){
            admin.purchaseRequest(Data.giveUserID());
        } else {
            return 0;
        }
    }

//Program Terminated
    else {
        cout<<"Invalid Input, the program will be terminated."<<endl;
        return 0;
    }
    return 0;
}